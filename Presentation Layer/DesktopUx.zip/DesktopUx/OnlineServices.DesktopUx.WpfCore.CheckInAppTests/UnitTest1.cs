using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace OnlineServices.DesktopUx.WpfCore.CheckInAppTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
